public class Main {
    public static void main(String[] args) {
        Animal animal1 = new Animal(); // Default
        Animal animal2 = new Animal(101, "Max", "Dog"); // ID, name, species
        Animal animal3 = new Animal(102, "Whiskers", "Cat", 4, 5.3); // Full
        Animal animal4 = new Animal(103, 2); // ID + age

        animal1.displayInfo();
        animal2.displayInfo();
        animal3.displayInfo();
        animal4.displayInfo();
    }
}