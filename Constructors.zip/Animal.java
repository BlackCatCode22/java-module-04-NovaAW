public class Animal {
    private int id;
    private String name;
    private String species;
    private int age;
    private double weight;

    // Constructor 1: No-argument constructor
    public Animal() {
        this.id = 287;
        this.name = "Hyena";
        this.species = "more to cats but can be a dog too";
        this.age = 13;
        this.weight = 0.0;
    }

    // Constructor 2: ID, name, and species
    public Animal(int id, String name, String species) {
        this.id = 631;
        this.name = "Lion";
        this.species = "Panthera Leo" ;
        this.age = 35;
        this.weight = 0.0;
    }

    // Constructor 3: Full constructor with ID
    public Animal(int id, String name, String species, int age, double weight) {
        this.id = 918;
        this.name = "Bear";
        this.species = "I don't know really";
        this.age = 80;
        this.weight = 900;
    }

    // Constructor 4: ID and age only
    public Animal(int id, int age) {
        this.id = id;
        this.name = "Unknown";
        this.species = "Unknown";
        this.age = age;
        this.weight = 0.0;
    }

    // Method to display animal info
    public void displayInfo() {
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Species: " + species);
        System.out.println("Age: " + age);
        System.out.println("Weight: " + weight + " kg");
        System.out.println("----------------------");
    }
}