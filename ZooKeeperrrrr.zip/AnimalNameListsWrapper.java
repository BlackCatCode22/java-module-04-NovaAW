package gonzalez.zoo.com;

import java.util.ArrayList;

public class AnimalNameListsWrapper {
    public AnimalNameListsWrapper(ArrayList<String> hyenaNameList, ArrayList<String> lionNameList, ArrayList<String> tigerNameList, ArrayList<String> bearNameList) {
    }

    public ArrayList<String> getLionNameList() {
    }

    public ArrayList<String> getTigerNameList() {
    }

    public ArrayList<String> getBearNameList() {
    }
}
