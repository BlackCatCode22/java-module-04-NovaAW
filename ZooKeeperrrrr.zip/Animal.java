package gonzalez.zoo.com;

public class Animal {
    // Static counter
    static int numOfAnimals = 0;

    // Attributes
    private String sex;
    private int age;
    private int weight;
    private String animalName;
    private String animalID;
    private String animalBirthDate;
    private String animalColor;
    private String animalOrigin;
    private String animalArrivalDate;

    // default constructor increments animal count
    public Animal() {
        numOfAnimals++;
    }

    // constructor with all fields and more
    public Animal(String sex, int age, int weight, String animalName,
                  String animalID, String animalBirthDate, String animalColor,
                  String animalOrigin, String animalArrivalDate) {
        numOfAnimals++;
        this.sex = sex;
        this.age = age;
        this.weight = weight;
        this.animalName = animalName;
        this.animalID = animalID;
        this.animalBirthDate = animalBirthDate;
        this.animalColor = animalColor;
        this.animalOrigin = animalOrigin;
        this.animalArrivalDate = animalArrivalDate;
    }

    // all the IDS names and more
    public String getAnimalOrigin() { return animalOrigin; }
    public void setAnimalOrigin(String animalOrigin) { this.animalOrigin = animalOrigin; }

    public String getAnimalColor() { return animalColor; }
    public void setAnimalColor(String animalColor) { this.animalColor = animalColor; }

    public String getAnimalBirthDate() { return animalBirthDate; }
    public void setAnimalBirthDate(String animalBirthDate) { this.animalBirthDate = animalBirthDate; }

    public String getAnimalID() { return animalID; }
    public void setAnimalID(String animalID) { this.animalID = animalID; }

    public String getAnimalName() { return animalName; }
    public void setAnimalName(String animalName) { this.animalName = animalName; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getSex() { return sex; }
    public void setSex(String sex) { this.sex = sex; }

    public int getWeight() { return weight; }
    public void setWeight(int weight) { this.weight = weight; }

    public String getAnimalArrivalDate() { return animalArrivalDate; }
    public void setAnimalArrivalDate(String animalArrivalDate) { this.animalArrivalDate = animalArrivalDate; }

    // Added a nice string method to the output
    @Override
    public String toString() {
        return String.format(
                "%s (ID: %s), Name: %s, Sex: %s, Age: %d years, Weight: %d lbs, Color: %s, Birth: %s, Origin: %s, Arrived: %s",
                this.getClass().getSimpleName(),
                animalID,
                animalName,
                sex,
                age,
                weight,
                animalColor,
                animalBirthDate,
                animalOrigin,
                animalArrivalDate
        );
    }
}
