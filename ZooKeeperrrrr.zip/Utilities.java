package gonzalez.zoo.com;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Utilities {

    // Generate an ID based on the species
    public static String calcAnimalID(String animalSpecies) {
        String myID = "";
        animalSpecies = animalSpecies.toLowerCase();

        if (animalSpecies.contains("hy")) {
            int num = Hyena.numOfHyenas + 1;
            myID = "Hy" + String.format("%02d", num);
        } else if (animalSpecies.contains("li")) {
            int num = Lion.numOfLions + 1;
            myID = "Li" + String.format("%02d", num);
        } else if (animalSpecies.contains("ti")) {
            int num = Tiger.numOfTigers + 1;
            myID = "Ti" + String.format("%02d", num);
        } else if (animalSpecies.contains("be")) {
            int num = Bear.numOfBears + 1;
            myID = "Be" + String.format("%02d", num);
        }

        return myID;
    }

    // Get today's date as arrival date
    public static String arrivalDate() {
        Date today = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        return formatter.format(today);
    }

    // Calculate animal birth date based on age and season
    public static String calcAnimalBirthDate(int age, String theSeason) {
        Date today = new Date();
        SimpleDateFormat formatterYear = new SimpleDateFormat("yyyy");
        int currentYear = Integer.parseInt(formatterYear.format(today));
        int birthYear = currentYear - age;

        String season = theSeason.toLowerCase();
        String birthDate;

        switch (season) {
            case "spring":
                birthDate = birthYear + "-03-21";
                break;
            case "summer":
                birthDate = birthYear + "-06-21";
                break;
            case "fall":
                birthDate = birthYear + "-09-21";
                break;
            case "winter":
                birthDate = birthYear + "-12-21";
                break;
            default:
                birthDate = birthYear + "-01-01"; // fallback
        }

        return birthDate;
    }

    // Read animal names from a file and group them into species-specific lists
    public static AnimalNameListsWrapper createAnimalNameLists(String filePath) {
        ArrayList<String> hyenaNameList = new ArrayList<>();
        ArrayList<String> lionNameList = new ArrayList<>();
        ArrayList<String> tigerNameList = new ArrayList<>();
        ArrayList<String> bearNameList = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            ArrayList<String> currentList = null;

            while ((line = reader.readLine()) != null) {
                line = line.trim();

                if (line.equalsIgnoreCase("Hyena Names:")) {
                    currentList = hyenaNameList;
                } else if (line.equalsIgnoreCase("Lion Names:")) {
                    currentList = lionNameList;
                } else if (line.equalsIgnoreCase("Tiger Names:")) {
                    currentList = tigerNameList;
                } else if (line.equalsIgnoreCase("Bear Names:")) {
                    currentList = bearNameList;
                } else if (!line.isEmpty()) {
                    String[] names = line.split(",\\s*");
                    if (currentList != null) {
                        for (String name : names) {
                            currentList.add(name);
                        }
                    }
                }
            }

        } catch (IOException e) {
            System.out.println("Error reading animal name file: " + e.getMessage());
        }

        return new AnimalNameListsWrapper(hyenaNameList, lionNameList, tigerNameList, bearNameList);
    }
}
