package gonzalez.zoo.com;

import javax.swing.text.Utilities;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

import static javax.swing.text.Utilities.getPositionBelow;

public class App {

    public static void main(String[] args) {
        System.out.println("Welcome to my Zoo Program!");

        String nameFilePath = "animalNames.txt";
        String dataFilePath = "arrivingAnimals.txt";

        // Load names from animalNames.txt
        AnimalNameListsWrapper animalLists = toString(nameFilePath);

        ArrayList<String> hyenaNames = animalLists.getLionNameList();
        ArrayList<String> lionNames = animalLists.getLionNameList();
        ArrayList<String> tigerNames = animalLists.getTigerNameList();
        ArrayList<String> bearNames = animalLists.getBearNameList();

        // List to store all animal objects
        ArrayList<Object> zooAnimals = new ArrayList<>();

        // Map to count each species
        HashMap<String, Integer> speciesCount = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(dataFilePath))) {
            String line;

            while ((line = reader.readLine()) != null) {
                // Example line:
                // "3 years old male hyena, Born in Spring, brown, 120 pounds, Friguia Park, Tunisia"

                String[] commaParts = line.split(", ");
                String mainInfo = commaParts[0];              // "3 years old male hyena"
                String birthSeason = commaParts[1].split(" ")[2];  // "Spring"
                String color = commaParts[2];

                // Clean weight (remove non-digit characters)
                String weightStr = commaParts[3].replaceAll("[^\\d]", "");
                int weight = Integer.parseInt(weightStr);

                // Origin
                String origin = commaParts[4] + ", " + commaParts[5];

                // Parse main info
                String[] mainInfoParts = mainInfo.split(" ");
                String ageStr = mainInfoParts[0].replaceAll("[^\\d]", "");  // "3"
                int age = Integer.parseInt(ageStr);

                String sex = mainInfoParts[3];          // "male"
                String species = mainInfoParts[4].toLowerCase(); // "hyena"

                // Generate attributes
                String arrivalDate = Utilities.drawTabbedText();
                String animalID = Utilities.getRowEnd(species);
                String birthDate;
                birthDate = Utilities.drawTabbedText(age, birthSeason);
                String name;

                // Create correct animal subclass
                switch (species) {
                    case "hyena":
                        name = hyenaNames.remove(0);
                        Hyena hyena = new Hyena(sex, age, weight, name, animalID, birthDate, color, origin, arrivalDate);
                        zooAnimals.add(hyena);
                        break;
                    case "lion":
                        name = lionNames.remove(0);
                        Lion lion = new Lion(sex, age, weight, name, animalID, birthDate, color, origin, arrivalDate);
                        zooAnimals.add(lion);
                        break;
                    case "tiger":
                        name = tigerNames.remove(0);
                        Tiger tiger = new Tiger(sex, age, weight, name, animalID, birthDate, color, origin, arrivalDate);
                        zooAnimals.add(tiger);
                        break;
                    case "bear":
                        name = bearNames.remove(0);
                        Bear bear;
                        bear = new Bear(sex, age, weight, name, animalID, birthDate, color, origin, arrivalDate);
                        zooAnimals.add(bear);
                        break;
                    default:
                        System.out.println("Unknown species: " + species);
                        continue;  // Skip counting if unknown
                }

                // Count species
                speciesCount.put(species, speciesCount.getOrDefault(species, 0) + 1);
            }

        } catch (IOException e) {
            System.out.println("Error reading animal file.");
            e.printStackTrace();
        }

        // Display Zoo Animal Report
        System.out.println("\nZoo Animal Report:\n");
        for (Object animal : zooAnimals) {
            System.out.println(animal);
        }

        // Display species counts
        System.out.println("\nAnimal Species Count:");
        for (String species : speciesCount.keySet()) {
            System.out.println(capitalize(species) + "s: " + speciesCount.get(species));
        }
        System.out.println("Total Animals: " + Animal.numOfAnimals);

        // Write Zoo Animal Report to newAnimals.txt
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("newAnimals.txt"))) {
            for (Object animal : zooAnimals) {
                writer.write(animal.toString());
                writer.newLine();
            }
            writer.newLine();
            writer.write("Animal Species Count:\n");
            for (String species : speciesCount.keySet()) {
                writer.write(capitalize(species) + "s: " + speciesCount.get(species));
                writer.newLine();
            }
            writer.write("Total Animals: " + Animal.numOfAnimals);
        } catch (IOException e) {
            System.out.println("Error writing output file.");
            e.printStackTrace();
        }
    }

    // Helper to capitalize species names nicely
    public static String capitalize(String str) {
        if (str == null || str.isEmpty()) return str;
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }
}
